
<?php
class Servico {
    public $id;
    public $nome;
    public $descricao;
    public $preco;
    public $duracao;

    public function __construct($id, $nome, $descricao, $preco, $duracao) {
        $this->id = $id;
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->preco = $preco;
        $this->duracao = $duracao;
    }
}
?>
