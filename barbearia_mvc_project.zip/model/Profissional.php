
<?php
class Profissional {
    public $id;
    public $nome;
    public $especialidade;
    public $contato;

    public function __construct($id, $nome, $especialidade, $contato) {
        $this->id = $id;
        $this->nome = $nome;
        $this->especialidade = $especialidade;
        $this->contato = $contato;
    }
}
?>
