
<?php
require_once '../model/Servico.php';
require_once '../config/config.php';

class ServicoController {
    public function listar() {
        // List services
    }

    public function adicionar($nome, $descricao, $preco, $duracao) {
        // Add new service
    }

    public function editar($id, $nome, $descricao, $preco, $duracao) {
        // Edit existing service
    }

    public function excluir($id) {
        // Delete service
    }
}
?>
