
<?php
require_once '../model/Profissional.php';
require_once '../config/config.php';

class ProfissionalController {
    public function listar() {
        // List professionals
    }

    public function adicionar($nome, $especialidade, $contato) {
        // Add new professional
    }

    public function editar($id, $nome, $especialidade, $contato) {
        // Edit existing professional
    }

    public function excluir($id) {
        // Delete professional
    }
}
?>
